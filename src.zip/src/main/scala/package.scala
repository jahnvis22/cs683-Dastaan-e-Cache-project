package memGen

package object accel {
  val config = chipsalliance.rocketchip.config
}
